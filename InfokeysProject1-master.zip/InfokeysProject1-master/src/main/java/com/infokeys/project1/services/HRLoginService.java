/*package com.infokeys.project1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokeys.project1.dao.HRdao;

@Service("hrloginService")
public class HRLoginService {

	@Autowired
	private HRdao hRdao;

	public boolean loginChecks(String username, String password) {
		return hRdao.loginCheck(username, password);
	}

}
*/