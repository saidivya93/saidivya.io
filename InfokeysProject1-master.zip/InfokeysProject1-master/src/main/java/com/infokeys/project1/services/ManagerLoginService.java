/*package com.infokeys.project1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokeys.project1.dao.ManagerDao;

@Service("managerloginService")
public class ManagerLoginService {

	@Autowired
	private ManagerDao managerdao;

	public boolean loginChecks(String username, String password) {
		return managerdao.loginCheck(username, password);
	}

}*/
